#!/bin/bash
/Users/Carlistle/Developer/PyCharmWorkspace/pyenv/bin/python /Users/Carlistle/Developer/PyCharmWorkspace/pyenv/CuteImage.app/Contents/MacOS/MainLauncher.py