# CuteImage
Final bug fix completed

https://medium.com/100-days-of-algorithms/day-96-floyd-steinberg-7c5b25ee0a65\
https://hhsprings.bitbucket.io/docs/programming/examples/python/PIL/ImageFilter.html\
https://hhsprings.bitbucket.io/docs/programming/examples/python/PIL/Image__class_Image.html#convert